﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Drawing;
using System.Drawing.Imaging;

namespace CPBitmap_Converter
{
    class CPBitmap
    {
        /// <summary>
        /// The Stream to load the file through
        /// </summary>
        private Stream _fileStream;

        /// <summary>
        /// Bitmap object to store the bitmap in
        /// </summary>
        public Bitmap BitmapObject { get; private set; }

        /// <summary>
        /// Unknown field #1 - position 153600 in the file
        /// </summary>
        public int UnknownField1 { get; private set; }
        /// <summary>
        /// Width of the picture stored in the file at position 153601
        /// </summary>
        public int WidthInFile { get; private set; }
        /// <summary>
        /// Height of the picture stored in the file at position 153602
        /// </summary>
        public int HeightInFile { get; private set; }
        /// <summary>
        /// Unknown field #2 - position 153603 in the file
        /// </summary>
        public int UnknownField2 { get; private set; }
        /// <summary>
        /// Unknown field #3 - position 153604 in the file
        /// </summary>
        public int UnknownField3 { get; private set; }
        /// <summary>
        /// Unknown field #4 - position 153605 in the file
        /// </summary>
        public int UnknownField4 { get; private set; }

        /// <summary>
        /// Constructor - supply a stream and the Load function does the rest.
        /// </summary>
        /// <param name="fileStream">Filestream pointing to the CPBitmap file to load.</param>
        public CPBitmap(Stream fileStream)
        {
            _fileStream = fileStream;
            
            // Load the CPBitmap file
            Load();
        }

        private unsafe void Load()
        {
            // Create a temporary Bitmap to load the data into
            Bitmap _bitmap = new Bitmap(320, 480, PixelFormat.Format32bppPArgb);
            // Lock the Bitmap into memory so we can play with it
            BitmapData _bitmapData = _bitmap.LockBits(new Rectangle(0, 0, _bitmap.Width, _bitmap.Height), ImageLockMode.ReadWrite, PixelFormat.Format32bppPArgb);

            // Setup our pointer at 0,0
            int* xy = (int*)_bitmapData.Scan0.ToPointer();

            // Read the file in and add each 4-byte pixel (sizeof(int) = 4) to the pixel list
            using (BinaryReader _binaryReader = new BinaryReader(_fileStream))
            {
                int _filePosition = 0;

                int _fileLength = (int)_binaryReader.BaseStream.Length;

                while (_filePosition < _fileLength)
                {
                    // If this is less than the area where pixels are stored, then add it to the Bitmap
                    if (_filePosition < (153600 * sizeof(int))) // 320x480 = 153600
                    {
                        *(xy++) = _binaryReader.ReadInt32();
                    }
                    else
                    {
                        // If we've passed the pixel data.. then its the other data.
                        switch (_filePosition)
                        {
                            case (153600 * sizeof(int)):
                                // Bit field, unknown use
                                UnknownField1 = _binaryReader.ReadInt32();
                                break;
                            case (153600 * sizeof(int)) + 4:
                                WidthInFile = _binaryReader.ReadInt32();
                                break;
                            case (153600 * sizeof(int)) + 8:
                                HeightInFile = _binaryReader.ReadInt32();
                                break;
                            case (153600 * sizeof(int)) + 12:
                                // Bit field, unknown use
                                UnknownField2 = _binaryReader.ReadInt32();
                                break;
                            case (153600 * sizeof(int)) + 16:
                                // Bit field, unknown use
                                UnknownField3 = _binaryReader.ReadInt32();
                                break;
                            case (153600 * sizeof(int)) + 20:
                                // I have no idea what this value stands for..
                                UnknownField4 = _binaryReader.ReadInt32();
                                break;
                        }
                    }
                    _filePosition += sizeof(int);
                }
            }

            // Unlock the Bitmap
            _bitmap.UnlockBits(_bitmapData);
            // Store the result
            BitmapObject = _bitmap;
        }

        /// <summary>
        /// Just removes the bitmap
        /// </summary>
        public void Reset()
        {
            BitmapObject = null;
        }
    }
}
