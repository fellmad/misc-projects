﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Drawing.Imaging;

namespace CPBitmap_Converter
{
    public partial class Form1 : Form
    {
        CPBitmap cpBitmap;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            button2_Click(sender, e);
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            if (cpBitmap != null)
            {
                e.Graphics.DrawImage(cpBitmap.BitmapObject, 0, 0);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Apple CPBitmap file|*.cpbitmap";
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {

                // Setup a FileStream object pointing to the file
                FileStream fs = new FileStream(openFileDialog1.FileName, FileMode.Open, FileAccess.Read);

                // Load the new CPBitmap
                cpBitmap = new CPBitmap(fs);

                // Show width and height
                label3.Text = cpBitmap.WidthInFile.ToString();
                label4.Text = cpBitmap.HeightInFile.ToString();

                fs.Close();

                pictureBox1.Invalidate();
                button1.Enabled = true;
            }
            else
            {
                cpBitmap = null;
                button1.Enabled = false;
                pictureBox1.Invalidate();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Filter = "JPEG Image|*.jpg;*.jpeg";

            if (saveFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                cpBitmap.BitmapObject.Save(saveFileDialog1.FileName, ImageFormat.Jpeg);
            }
        }
    }
}
